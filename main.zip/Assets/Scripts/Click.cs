using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Click : MonoBehaviour
{
    public DisplayItem displayScript;

    public string itemName;
    [Multiline]
    public string itemDescription;
    [HideInInspector]
    public SpriteRenderer itemSprite;

    /// <summary>
    /// CLEAN UP INSPECTOR UPDATE
    /// </summary>0
     

    public bool CleanUp = true;
    public SpriteRenderer repairedSprite;


#if UNITY_EDITOR
    [CustomEditor(typeof(Click))]
    class MyClassEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            Click self = (Click)target;
            serializedObject.Update();
            if (self.CleanUp)
                DrawDefaultInspector();
            else
            {
                DrawPropertiesExcluding(serializedObject, "repairedSprite");
            }
            serializedObject.ApplyModifiedProperties();
        }
    }
#endif


    /// <summary>
    /// CODE
    /// </summary>


    private void Start()
    {
        itemSprite = GetComponent<SpriteRenderer>();
    }

    private void OnMouseDown()
    {
        if (displayScript.isDisplaying == false)
        {
            if (CleanUp == true)
            {
                displayScript.EnableDisplay(itemName, itemDescription, repairedSprite);
                itemSprite.sprite = repairedSprite.sprite;
                gameObject.GetComponent<BoxCollider2D>().enabled = false;
            }
            else
            {
                displayScript.EnableDisplay(itemName, itemDescription, itemSprite);
                RemoveItem();
            }
        }
    }

    private void RemoveItem()
    {
        Destroy(gameObject);
    }

}
