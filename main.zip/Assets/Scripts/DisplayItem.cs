using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.U2D;
using UnityEngine.UI;

public class DisplayItem : MonoBehaviour
{
    public GameManager GameManager;

    [HideInInspector]
    public bool isDisplaying = false;

    public GameObject panel;
    public TMP_Text itemNameDisplay;
    public TMP_Text itemDescDisplay;
    public GameObject itemImgDisplay;
    public Animator popUpAnim;

    public Image img;

    public void DisableDisplay()
    {
        isDisplaying = false;
        panel.SetActive(false);
        GameManager.AddToScore();
    }

    public void EnableDisplay(string itemName, string itemDesc, SpriteRenderer itemSprite)
    {
        panel.SetActive(true);
        popUpAnim.Play("popup");
        itemNameDisplay.text = itemName;
        itemDescDisplay.text = itemDesc;
        itemImgDisplay.GetComponent<Image>().sprite = itemSprite.sprite;
        isDisplaying = true;
    }
}
