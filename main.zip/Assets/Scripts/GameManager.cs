using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameManager gameManager;
    [HideInInspector]
    public int score;
    public GameObject winScreen;
    private Click[] yourObjects;
    [HideInInspector]
    public int scoreToWin;
    public Image mask;

    public void Start()
    {
        yourObjects = FindObjectsOfType<Click>();
        for(int i = 0; i < yourObjects.Length; i++)
        {
            scoreToWin++;
        }
    }

    public void AddToScore()
    {
        score++;
        GetCurrentFill();
        if(score == scoreToWin)
        {
            WinState();
        }
    }

    private void WinState()
    {
        Debug.Log("YouWin");
        winScreen.SetActive(true);
    }

    void GetCurrentFill()
    {
        float fillAmount = (float)score / (float)scoreToWin;
        mask.fillAmount = fillAmount;
    }
}
